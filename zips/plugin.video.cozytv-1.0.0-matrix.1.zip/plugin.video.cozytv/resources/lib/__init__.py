# -*- coding: utf-8 -*-
#    Copyright (C) 2022 tracey-fans (plugin.video.cozytv)
#
#    SPDX-License-Identifier: MIT
#    See LICENSES/MIT.md for more information.
